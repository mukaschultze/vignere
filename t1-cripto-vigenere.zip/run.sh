rm a.out
gcc -Wall vigenere.c
./a.out